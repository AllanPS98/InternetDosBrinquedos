/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import java.awt.Color;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;

/**
 *
 * @author allan
 */
public class Cliente {

    ObjectOutputStream out;
    ObjectInputStream in;
    Simulador thread;
    Socket cliente;
    public static boolean verificaSeExisteCorrida = false;
    public static List<Jogador> jogadores = null;
    public static List<Carro> carros = null;
    public static Corrida corrida;
    public static Corrida qualify;
    public static Recorde recordeCorrida;
    public static Recorde recordeQualify;
    public void cliente() throws IOException {
        cliente = new Socket("127.0.0.1", 12345);
        out = new ObjectOutputStream(cliente.getOutputStream());
        in = new ObjectInputStream(cliente.getInputStream());
        System.out.println("CLIENTE CONECTADO");
        
    }

    public void cadastroUsuario(String nome, String equipe) {
        Jogador jog = new Jogador(nome, equipe);
        try {
            output(Protocolo.CADASTRO_USUARIO);
            System.out.println(jog.toString());
            output(jog);
            boolean cadastrou = (boolean) input();
            if (cadastrou) {
                System.out.println("Jogador cadastrado com sucesso");
            } else {
                System.out.println("Jogador não cadastrado. Tente um nome diferente.");
            }
            sair();
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    
    public void encerra() throws IOException{
        output(Protocolo.SAIR);
        sair();
    }

    public void cadastroADM(String nome, String senha) {
        Administrador adm = new Administrador(nome, senha);
        try {
            output(Protocolo.CADASTRO_ADM);
            output(adm);
            sair();
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void output(Object msg) throws IOException {
        out.flush();
        out.writeObject(msg);
        out.reset();
    }

    public Object input() throws IOException, ClassNotFoundException {
        return in.readObject();
    }
    
    public void iniciarCorrida(JTable tabelaCorri, JTable tabelaQuali){
        thread = new Simulador(cliente, out, in, tabelaCorri, tabelaQuali);
        Thread t = new Thread(thread);
        t.start();
    }
    
    

    public Corrida atualizarClassificacao() throws IOException, ClassNotFoundException {
        return thread.retornaLista();
    }
    

    public boolean login(String login, String senha) throws IOException, ClassNotFoundException {
        Administrador adm = new Administrador(login, senha);
        output(Protocolo.LOGIN);
        output(adm);
        return (boolean) input();
    }

    public String cadastroCarro(int numero, String cores, String tag) throws ClassNotFoundException {
        Color cor = identificarCor(cores.toLowerCase());
        boolean cadastrou;
        if (cor != null) {
            Carro carro = new Carro(numero, cor, tag);
            try {
                output(Protocolo.CADASTRO_CARRO);
                System.out.println(carro.toString());
                output(carro);
                cadastrou = (boolean) input();
                sair();
                if (cadastrou) {
                    return "Carro cadastrado com sucesso!";
                } else {
                    return "Número do carro já existe. Tente outro!";
                }

            } catch (IOException ex) {
                Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
                return "ERRO DESCONHECIDO!";
            }
        } else {
            return "Cor inválida, tente novamente";
        }
    }

   
    
    
    public void sair() {
        try {
            output(Protocolo.SAIR);
            out.close();
            in.close();
            cliente.close();
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("CLIENTE DESCONECTADO !!!!!");
    }

    public Color identificarCor(String cor) {
        cor = cor.toLowerCase();
        switch (cor) {
            case "vermelho":
                return Color.RED;
            case "azul":
                return Color.BLUE;
            case "amarelo":
                return Color.YELLOW;
            case "rosa":
                return Color.PINK;
            case "preto":
                return Color.BLACK;
            case "cinza":
                return Color.GRAY;
            case "branco":
                return Color.WHITE;
            case "laranja":
                return Color.ORANGE;
            case "verde":
                return Color.GREEN;
        }
        return null;
    }

    public void carregar() {
        try {
            output(Protocolo.CORRIDA);
            verificaSeExisteCorrida = (boolean) input();
            jogadores = (List<Jogador>) input();
            carros = (List<Carro>) input();
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public String cadastroCorrida(int tempo, int voltas, List<Jogador> participantes, List<Carro> carrosSelecionados) {
        
        if (!verificaSeExisteCorrida) { // se não existe nenhuma corrida cadastrada, podemos cadastra uma
            if (carrosSelecionados.size() < 2 || participantes.size() < 2) {

                try {
                    output(false);
                } catch (IOException ex) {
                    Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
                }
                return "Precisa ter ao menos 2 jogadores e 2 carros cadastrados para ser realizada uma corrida.";

            } else { // se eu tenho mais de 1 carro e mais de um jogador cadastrado, podemos continuar o cadastro
                
                for (int i = 0; i < participantes.size(); i++) {
                    participantes.get(i).setCarro(carrosSelecionados.get(i));
                    System.out.println(participantes.get(i).toStringComCarro());
                }
                try {// caso todas as condições necessárias pra uma corrida existir sejam satisfeitas
                    if (participantes.size() > 1) {
                        output(true); // envio para o servidor uma mensagem dizendo "pode cadastrar aí"
                        qualify = new Corrida(participantes);
                        qualify.setTempoDeQualificacao(tempo);
                        qualify.setQtdVoltas(voltas);
                        corrida = new Corrida(participantes);
                        corrida.setTempoDeQualificacao(tempo);
                        corrida.setQtdVoltas(voltas);
                        output(corrida);
                        output(qualify);
                        verificaSeExisteCorrida = true;
                        return "Corrida cadastrada";
                    } else {
                        output(false);
                        return "É necessário 2 ou mais jogadores para ser realizada a corrida. Tente novamente!";
                    }
                } catch (IOException ex) {
                    Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } else {
            try {
                output(false);

            } catch (IOException ex) {
                Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            return "Já existe um cadastro de corrida, para cadastrar uma nova, finalize a atual";
        }
        return "ERRO DESCONHECIDO";
    }

    public Corrida listarCorridaCadastrada() {
        try {
            output(Protocolo.LISTAR_CORRIDA_CADASTRADA);
            boolean existeCorrida = (boolean) input();
            if (existeCorrida) {
                corrida = (Corrida) input();
                
                return corrida;
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public void finalizarCorrida() throws IOException, ClassNotFoundException {
        output(Protocolo.FINALIZAR_CORRIDA);
        verificaSeExisteCorrida = false;
        sair();
        
    }
    
    public void pegarRecorde() throws IOException, ClassNotFoundException{
        output(Protocolo.PEGAR_RECORDE);
        recordeCorrida = (Recorde) input();
        recordeQualify = (Recorde) input();
        
    }
    
}
