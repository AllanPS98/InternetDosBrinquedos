/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.io.*;
import java.net.*;

/**
 *
 * @author User
 */
public class ServidorUDP {

    /**
     * @param args the command line arguments
     * @throws java.net.SocketException
     */
    public static void main(String[] args) throws SocketException, IOException {
        int porta = 12345;
        int numConn = 1;
        DatagramSocket serverSocket = new DatagramSocket(porta);
        byte[] receiveData = new byte[1024];
        byte[] sendData = new byte[1024];
        System.out.println("Esperando por datagrama UDP na porta " + porta);
        while (true) {
            DatagramPacket receivePacket = new DatagramPacket(receiveData,receiveData.length);
            serverSocket.receive(receivePacket);
            //System.out.println("Datagrama UDP [" + numConn + "] recebido...");
            ThreadUDP thr = new ThreadUDP(receivePacket);
            Thread t = new Thread(thr);
            t.start();
        }

    }
}
