/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import cliente.Sensor;
import java.net.DatagramPacket;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author User
 */
public class ThreadUDP implements Runnable{
    
    private final DatagramPacket receive;
    public static List<Sensor> lista = new LinkedList();
    ThreadUDP(DatagramPacket receivePacket) {
        this.receive = receivePacket;
        
    }
    
    @Override
    public void run(){
        String str = new String(receive.getData());
        //System.out.println("Mensagem: " + str);
        String[] str2;
        
        str2 = str.split(",");
        //System.out.println("Tag: "+str2[0]);
        //System.out.println("Tempo: "+str2[1]);
        String[] str3;
        //Sensor sens = new Sensor();
        str3 = str2[1].split(":");
        //System.out.println("Segundos = " + str3[2]);
        float tempo;
        tempo = (float) Double.parseDouble(str3[2]);
        Sensor sens = new Sensor(str2[0], tempo);
        System.out.println("Sensor = " + sens.toString());
        lista.add(sens);
        System.out.println(lista);
    }
}
