#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//
#include <sys/types.h>
#include <sys/socket.h>
//struct sockaddr_in, htons() e outras
#include <netinet/in.h>
//funções inet_*()
#include <arpa/inet.h>

#include <errno.h> /*perror()*/
#include <unistd.h> /*close()*/

int main()
{
   int sockfd;
   int bytes;
   socklen_t length;
   char send_buffer[128];
   struct sockaddr_in server;
   
   sockfd = socket(AF_INET, SOCK_STREAM, 0);
   if(sockfd < 0)
   {
      perror("client_sockfd:::");
      exit(1);
   }
   
   
      server.sin_family  =  AF_INET;
      //NOTE:aqui é meio sem garantia, mas espero que voce não erre ao passar o numero da porta.
      server.sin_port    =  htons(8080);
      server.sin_addr.s_addr  =  inet_addr("127.0.0.1");
      memset(&(server.sin_zero), 0x00, 8);
   
   
   
   
   //conectando-se ao servidor
   length = sizeof(struct sockaddr);
   if(connect(sockfd, (struct sockaddr *)&server, length) < 0)
   {
      perror("client_connect:::");
      close(sockfd);
      exit(1);
   }
   
   quit = 'N';
   while(1)
   {
      //bytes = recv(sockfd, recv_buffer, 128, 0);
      //supondo que não ocorreu um erro acima
      //recv_buffer[bytes] = 0x00;//ponha o caractere '{FONTE}'
      
      //servidor fechou a conexão ou ocorreu um erro
      if(bytes <= 0)//ocorreu um erro = -1, fechou conexão = 0
      {
         perror("client_recv:::");
         close(sockfd);
         exit(1);
      }
      
      printf("\nDIGITE UMA MENSAGEM PARA ENVIAR AO SERVIDOR:\n");
      //lendo da entrada padrão
      //fgets(send_buffer, 128, stdin);
      //se no inicio da string estiver o 'S' então esse é o ultimo loop
		strcpy(send_buffer, "Oi servidor");
      quit = send_buffer[0];
      
      //enviando string ao servidor. strlen(send_buffer) pode ser menor que 32
      bytes = send(sockfd, send_buffer, 128, 0);
      if(bytes < 0)
      {
         perror("client_send:::");
         close(sockfd);
         exit(1);
      }
      //só agora podemos ver a mensagem recebida do servidor
      printf("\nRECEBIDO:::%s\n\n", recv_buffer);
   }
   
   close(sockfd);
   
   return 0;
}
