/*
   para executar:
   $ ./server <num_da_porta>
   valeu!
*/   
   

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//
#include <sys/types.h>
#include <sys/socket.h>
//funções inet_*()
#include <arpa/inet.h>
//struct sockaddr_in, ntol e outras
#include <netinet/in.h>

#include <errno.h>
#include <unistd.h>

int main()
{
   int sockfd, new_sockfd;
   int bytes;
   socklen_t length;//para accept() e bind()
   char buffer[128];
   struct sockaddr_in server;
   struct sockaddr_in client;
   
   sockfd = socket(AF_INET, SOCK_STREAM, 0);
   if(sockfd < 0)
   {
      perror("server_sockfd:::");
      exit(1);
   }
   
  
      server.sin_family  =  AF_INET;
      //é meio arriscado usar atoi() aqui,
      //mas assim fica fácil escolher em que porta esperar por conexões
      server.sin_port    =  htons(8080);
      server.sin_addr.s_addr = INADDR_ANY;
      memset(&(server.sin_zero), 0x00, 8);
   
   
   
   length = sizeof(struct sockaddr);
   if(bind(sockfd, (struct sockaddr *)&server, length) < 0)
   {
      perror("server_bind:::");
      close(sockfd);
      exit(1);
   }
   
   //o servidor aceitará no máximo apenas duas conexões
   if(listen(sockfd, 2) < 0)
   {
      perror("server_listen:::");
      close(sockfd);
      exit(1);
   }
   
   printf("\nAguardando por conexões na porta %d...\n\n", 8080);
   
   //aguardando por conexões
   new_sockfd = accept(sockfd, (struct sockaddr *)&client, &length);
   if(new_sockfd < 0)
   {
      perror("server_accept:::");
      close(sockfd);
      exit(1);
   }

   printf("\nAceitando conexão de %s\n\n", inet_ntoa(client.sin_addr));
   
   int n = 0;
   while(1)
   {
      
      
		bytes = recv(new_sockfd, buffer, 128, 0);
		//NOTE:ocorreu um erro = -1 ou cliente fechou conexão = 0
      
		buffer[bytes] = '\0';
		n = strlen(buffer);
		if(n > 0)
			printf("\nRECEBIDO:::%s\n\n", buffer);
      
      
      
   }
   
   close(new_sockfd);
   close(sockfd);
   
   return 0;
}
