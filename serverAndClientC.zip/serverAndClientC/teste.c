#include <stdio.h>
#include <string.h>
int main(){
	char json[50];
	char *nome = "allanzjoao";
	int id = 21;	
	sprintf(json, "{ \"nome\" : \"%s\", \"idade\" : \"%d\" }\n", nome, id);
	char *nome2;
	nome2 = strrchr(nome,'z');
	char nome3[30];
	strncat(nome3,nome,5);
	printf("novo nome3: %s\n", nome3);
	printf("novo nome: %s\n", nome2);
	printf("msg: %s\n", json);
	return 0;
}

