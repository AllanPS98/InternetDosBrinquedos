In this folder you can find documentation on how to get started with M6ENano on linux (Ubuntu or Raspberry Pi etc).

see the .odt file for more information

add readcont.c that will read continues. For M6E nano:

./readcont tmr:///dev/ttyUSBO --ant 1,1
