/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import java.io.Serializable;

/**
 *
 * @author allan
 */
public class Sensor implements Serializable{
    private String tag;
    private String tempo;
    private int horas;
    private int minutos;
    private int segundos;
    private int milis;
    private float time;

    public Sensor() {
    }

    public float getTime() {
        return time;
    }

    public void setTime(float time) {
        this.time = time;
    }

    public Sensor(String tag, String tempo) {
        this.tag = tag;
        this.tempo = tempo;
        this.horas = Integer.parseInt(tempo.split(":")[0]);
        this.minutos = Integer.parseInt(tempo.split(":")[1]);
        this.segundos = (int) Float.parseFloat(tempo.split(":")[2]);
        
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getTempo() {
        return tempo;
    }

    public void setTempo(String tempo) {
        this.tempo = tempo;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }

    public int getMinutos() {
        return minutos;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    public int getSegundos() {
        return  segundos;
    }

    public void setSegundos(int segundos) {
        this.segundos = segundos;
    }

    public int getMilis() {
        return milis;
    }

    public void setMilis(int milis) {
        this.milis = milis;
    }
    
    
    
    
    
    
    
}
