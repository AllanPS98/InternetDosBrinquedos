package servidor;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author allan
 */
public class Cronometro {
    public void cronos() throws InterruptedException{
        int segundos = 0;
        int minutos = 0;
        while(true){
           Thread.sleep(1000);
           segundos++;
           if(segundos == 60){
               segundos = 0;
               minutos++;
           }
           if(segundos < 10){
               System.out.println(minutos+":0"+segundos);
           }
           else{System.out.println(minutos+":"+segundos);}
        }
     }
}
        
        

