package servidor;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cliente.Administrador;
import cliente.Carro;
import cliente.Corrida;
import cliente.Jogador;
import cliente.Protocolo;
import cliente.Sensor;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import view.TelaCorrida;

/**
 *
 * @author allan
 */
public class ThreadTCP implements Runnable {

    private final Socket cliente;
    private final ObjectInputStream in;
    private final ObjectOutputStream out;
    
    private static Handler han;
    public static boolean verifica; // verifica se pode ou não atualizar o dado da corrida na tela na tela
    private static boolean finalize;
    private static boolean execQualify;
    private static boolean execCorrida;

    ThreadTCP(Socket cliente, ObjectInputStream in, ObjectOutputStream out, Handler han) {
        this.cliente = cliente;
        this.in = in;
        this.out = out;
        ThreadTCP.han = han;
    }

    @Override
    public void run() {

        try {
            // carrego os dados que estão nos arquivos do sistema
            carregarDados();

        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(ThreadTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
        int protocoloAtual;
        while (true) {
            try {
                
                protocoloAtual = (int) input(); // recebe o protocolo que vem do cliente
                System.out.println(protocoloAtual);
                if (protocoloAtual == Protocolo.SAIR) { // desconecta o cliente
                    sair();
                    break;
                } else if (protocoloAtual == Protocolo.CADASTRO_ADM) { // faz o cadastro de um administrador
                    Administrador admin = (Administrador) input();
                    han.cadastroADM(admin.getNome(), admin.getSenha());
                    han.escreverArquivoSerial("dados\\ADM\\listaADM", Handler.adms);
                } else if (protocoloAtual == Protocolo.CADASTRO_CARRO) { // faz o cadastro de um carro
                    Carro carro = (Carro) input();
                    boolean cadastrou = han.cadastrarCarro(carro.getNumero(), carro.getCor(), carro.getTag());
                    output(cadastrou);
                    han.escreverArquivoSerial("dados\\Carros\\listaCARRO", Handler.carros);
                } else if (protocoloAtual == Protocolo.CADASTRO_USUARIO) { // faz o cadastro de um usuário normal
                    Jogador jog = (Jogador) input();
                    System.out.println(jog.toString());
                    boolean cadastrou = han.cadastrarJogadores(jog.getNome(), jog.getEquipe());
                    output(cadastrou);
                    han.escreverArquivoSerial("dados\\Jogadores\\listaJOGADOR", Handler.jogadores);
                } else if (protocoloAtual == Protocolo.CORRIDA) { // faz o cadastro de uma corrida

                    output(Handler.existeCorrida);
                    output(Handler.jogadores);
                    output(Handler.carros);
                    try {
                        boolean cadastrar = (boolean) input();
                        if (cadastrar) { // se cadastrar for true o sistema pode chamar o handler pra efetuar o cadastro
                            Corrida corrida = (Corrida) input();
                            Corrida qualify = (Corrida) input();
                            han.cadastrarCorrida(corrida);
                            han.cadastrarQualify(qualify);
                        }
                    } catch (java.lang.ClassCastException ex) {
                        sair();
                        break;
                    }

                } else if (protocoloAtual == Protocolo.LISTAR_CORRIDA_CADASTRADA) { // se existir uma corrida cadastrada o servidor envia essa corrida ao cliente
                    boolean existeCorrida = Handler.existeCorrida;
                    output(existeCorrida);
                    if (existeCorrida) {
                        output(Handler.corrida);
                    }
                } else if (protocoloAtual == Protocolo.PEGAR_RECORDE) {
                    output(Handler.recordeCorrida);
                    output(Handler.recordeQualify);
                } else if (protocoloAtual == Protocolo.LOGIN) {
                    Administrador adm = (Administrador) input();
                    boolean podeLogar = false;
                    for (Administrador ad : Handler.adms) {
                        if (ad.getNome().equals(adm.getNome()) && ad.getSenha().equals(adm.getSenha())) {
                            podeLogar = true;
                        }
                    }
                    if (adm.getNome().equals("admin") && adm.getSenha().equals("admin")) {
                        podeLogar = true;
                    }
                    output(podeLogar);
                } else if (protocoloAtual == Protocolo.INICIAR_SIMULA) {
                    TelaCorrida.telaCorrida = new TelaCorrida();

                    output(ThreadUDP.finalizar);
                       
                    
                } else if (protocoloAtual == Protocolo.FINALIZAR_CORRIDA) {
                    ThreadUDP.checarRecordeCorrida();
                    ThreadUDP.checarRecordeQualify();
                    han.finalizarQualificacaoECorrida();
                    System.out.println("finalizou serv");
                } else if (protocoloAtual == Protocolo.ATUALIZAR_CORRIDA) {
                    output(Handler.corrida);

                }
            } catch (IOException | ClassNotFoundException ex) {
                System.out.println("jdjasdjiasdoasdio");
                Logger.getLogger(ThreadTCP.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InterruptedException ex) {
                Logger.getLogger(ThreadTCP.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    public Object input() throws IOException, ClassNotFoundException {
        System.out.println("entrou no input");
        try {
            System.out.println("entrou no primeiro try");
            InputStream tcpInput = new ObjectInputStream(in);
            System.out.println(tcpInput.toString());
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            ObjectOutputStream obj = new ObjectOutputStream(bytes);
            
            try {
                System.out.println("entrou no segundo try");
                obj.writeObject(((ObjectInputStream) tcpInput).readObject());
                bytes.toByteArray();
                Object mensagem = desserializarMensagem(bytes.toByteArray());
                System.out.println(mensagem.toString());
                return mensagem;
            } catch (ClassNotFoundException e) {
                Logger.getLogger(ThreadTCP.class.getName()).log(Level.SEVERE, null, e);
            }
        } catch (IOException e) {
            Logger.getLogger(ThreadTCP.class.getName()).log(Level.SEVERE, null, e);

        }
        return null;
    }

    public void output(Object msg) throws IOException {
        out.flush();
        out.write(serializarMensagens(msg));
        out.reset();
    }

    //chama o handler pra carregar os arquivos salvos no sistema
    public static void carregarDados() throws IOException, FileNotFoundException, ClassNotFoundException {
        han.lerArquivoSerial("dados\\ADM\\listaADM");
        han.lerArquivoSerial("dados\\Carros\\listaCARRO");
        han.lerArquivoSerial("dados\\Jogadores\\listaJOGADOR");
        han.lerArquivoSerial("dados\\Recordes\\recordeQualify");
        han.lerArquivoSerial("dados\\Recordes\\recordeCorrida");
    }

    private void sair() throws IOException {
        System.out.println("tentou sair");
        in.close();
        out.close();
        cliente.close();
        System.out.println("CLIENTE DESCONECTOU");
    }

    public byte[] serializarMensagens(Object mensagem) {
        ByteArrayOutputStream by = new ByteArrayOutputStream();
        try {
            ObjectOutput saida = new ObjectOutputStream(by);
            saida.writeObject(mensagem);
            saida.flush();
            return by.toByteArray();
        } catch (IOException ex) {
            Logger.getLogger(ThreadTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public Object desserializarMensagem(byte[] data) throws IOException, ClassNotFoundException {
        ByteArrayInputStream mensagem = new ByteArrayInputStream(data);

        ObjectInput leitor = new ObjectInputStream(mensagem);
        return (Object) leitor.readObject();

    }
}
