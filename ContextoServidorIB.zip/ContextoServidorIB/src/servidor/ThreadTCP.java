package servidor;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cliente.Administrador;
import cliente.Carro;
import cliente.Corrida;
import cliente.Jogador;
import cliente.Protocolo;
import cliente.Sensor;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author allan
 */
public class ThreadTCP implements Runnable {

    private final Socket cliente;
    private final ObjectInputStream in;
    private final ObjectOutputStream out;
    List<Sensor> tratamento = new ArrayList<>();
    private static Handler han;
    public static boolean verifica; // verifica se pode ou não atualizar o dado da corrida na tela na tela
    private static boolean finalize;
    private static boolean execQualify;
    private static boolean execCorrida;

    ThreadTCP(Socket cliente, ObjectInputStream in, ObjectOutputStream out, Handler han) {
        this.cliente = cliente;
        this.in = in;
        this.out = out;
        ThreadTCP.han = han;
    }

    @Override
    public void run() {
        

        try {
            // carrego os dados que estão nos arquivos do sistema
            carregarDados();

        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(ThreadTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
        int protocoloAtual;
        while (true) {
            try {
                protocoloAtual = (int) input(); // recebe o protocolo que vem do cliente

                if (protocoloAtual == Protocolo.SAIR) { // desconecta o cliente
                    sair();
                    break;
                } else if (protocoloAtual == Protocolo.CADASTRO_ADM) { // faz o cadastro de um administrador
                    Administrador admin = (Administrador) input();
                    han.cadastroADM(admin.getNome(), admin.getSenha());
                    han.escreverArquivoSerial("dados\\ADM\\listaADM", Handler.adms);
                } else if (protocoloAtual == Protocolo.CADASTRO_CARRO) { // faz o cadastro de um carro
                    Carro carro = (Carro) input();
                    boolean cadastrou = han.cadastrarCarro(carro.getNumero(), carro.getCor(), carro.getTag());
                    output(cadastrou);
                    han.escreverArquivoSerial("dados\\Carros\\listaCARRO", Handler.carros);
                } else if (protocoloAtual == Protocolo.CADASTRO_USUARIO) { // faz o cadastro de um usuário normal
                    Jogador jog = (Jogador) input();
                    System.out.println(jog.toString());
                    boolean cadastrou = han.cadastrarJogadores(jog.getNome(), jog.getEquipe());
                    output(cadastrou);
                    han.escreverArquivoSerial("dados\\Jogadores\\listaJOGADOR", Handler.jogadores);
                } else if (protocoloAtual == Protocolo.CORRIDA) { // faz o cadastro de uma corrida

                    output(Handler.existeCorrida);
                    output(Handler.jogadores);
                    output(Handler.carros);
                    try {
                        boolean cadastrar = (boolean) input();
                        if (cadastrar) { // se cadastrar for true o sistema pode chamar o handler pra efetuar o cadastro
                            Corrida corrida = (Corrida) input();
                            Corrida qualify = (Corrida) input();
                            han.cadastrarCorrida(corrida);
                            han.cadastrarQualify(qualify);
                        }
                    } catch (java.lang.ClassCastException ex) {
                        sair();
                        break;
                    }

                } else if (protocoloAtual == Protocolo.LISTAR_CORRIDA_CADASTRADA) { // se existir uma corrida cadastrada o servidor envia essa corrida ao cliente
                    boolean existeCorrida = Handler.existeCorrida;
                    output(existeCorrida);
                    if (existeCorrida) {
                        output(Handler.corrida);
                    }
                } else if (protocoloAtual == Protocolo.PEGAR_RECORDE) {
                    output(Handler.recordeCorrida);
                    output(Handler.recordeQualify);
                } else if (protocoloAtual == Protocolo.LOGIN) {
                    Administrador adm = (Administrador) input();
                    boolean podeLogar = false;
                    for (Administrador ad : Handler.adms) {
                        if (ad.getNome().equals(adm.getNome()) && ad.getSenha().equals(adm.getSenha())) {
                            podeLogar = true;
                        }
                    }
                    if (adm.getNome().equals("admin") && adm.getSenha().equals("admin")) {
                        podeLogar = true;
                    }
                    output(podeLogar);
                } else if (protocoloAtual == Protocolo.INICIAR_SIMULA) {

                    Sensor tags = (Sensor) input();
                    System.out.println(tags.toString());
                    //eliminarRajada(tags);
                    finalize = false;
                    if (Handler.corrida.getJogadores().get(Handler.corrida.getJogadores().size() - 1).getVoltas() == Handler.corrida.getQtdVoltas()) {
                        finalize = true;
                        execQualify = false;
                        execCorrida = false;
                    }
                    output(finalize);
                    output(verifica);
                    output(execQualify);
                    if (execQualify) {
                        output(Handler.qualify);
                    } else {
                        output(Handler.corrida);
                    }

                } else if (protocoloAtual == Protocolo.FINALIZAR_CORRIDA) {
                    //checarRecordeQualify();
                    //checarRecordeCorrida();
                    han.finalizarQualificacaoECorrida();
                    System.out.println("finalizou serv");
                } else if (protocoloAtual == Protocolo.ATUALIZAR_CORRIDA) {
                    output(Handler.corrida);

                }
            } catch (IOException | ClassNotFoundException ex) {
                System.out.println("jdjasdjiasdoasdio");
                Logger.getLogger(ThreadTCP.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    public Object input() throws IOException, ClassNotFoundException {
        return in.readObject();
    }

    public void output(Object msg) throws IOException {
        out.flush();
        out.writeObject(msg);
        out.reset();
    }

    //chama o handler pra carregar os arquivos salvos no sistema
    public static void carregarDados() throws IOException, FileNotFoundException, ClassNotFoundException {
        han.lerArquivoSerial("dados\\ADM\\listaADM");
        han.lerArquivoSerial("dados\\Carros\\listaCARRO");
        han.lerArquivoSerial("dados\\Jogadores\\listaJOGADOR");
        han.lerArquivoSerial("dados\\Recordes\\recordeQualify");
        han.lerArquivoSerial("dados\\Recordes\\recordeCorrida");
    }        
    
    private void sair() throws IOException {
        in.close();
        out.close();
        cliente.close();
        System.out.println("CLIENTE DESCONECTOU");
    }

}
