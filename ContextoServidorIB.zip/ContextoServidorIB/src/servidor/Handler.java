/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import cliente.Administrador;
import cliente.Carro;
import cliente.Corrida;
import cliente.Jogador;
import cliente.Recorde;
import java.awt.Color;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author allan
 */
public class Handler {
    public static List<Jogador> jogadores = new LinkedList();
    public static List<Carro> carros = new ArrayList();
    public static List<Administrador> adms = new ArrayList();
    public static Handler han;
    public static Corrida corrida;
    public static Corrida qualify;
    public static boolean existeCorrida;
    public static Recorde recordeQualify;
    public static Recorde recordeCorrida;
    
    private Handler() {
        
    }
    
    public void cadastrarCorrida(Corrida corrida){
        Handler.corrida = corrida;
        existeCorrida = true;
    }
    public void cadastrarQualify(Corrida corrida){
        Handler.qualify = corrida;
    }
    public boolean finalizarQualificacaoECorrida(){   
        if(existeCorrida){
            for(int i = 0; i < corrida.getJogadores().size(); i++){
                corrida.getJogadores().get(i).setPosicao(0);
                corrida.getJogadores().get(i).setTempoCorrida(0);
                corrida.getJogadores().get(i).setTempoVolta(0);
                corrida.getJogadores().get(i).setVoltaRapida((float) Double.MAX_VALUE);
                corrida.getJogadores().get(i).setVoltas(0);
                corrida.getJogadores().remove(i);
                qualify.getJogadores().get(i).setPosicao(0);
                qualify.getJogadores().get(i).setTempoCorrida(0);
                qualify.getJogadores().get(i).setTempoVolta(0);
                qualify.getJogadores().get(i).setVoltaRapida((float) Double.MAX_VALUE);
                qualify.getJogadores().get(i).setVoltas(0);
                qualify.getJogadores().remove(i);
            }
            corrida.setQtdVoltas(0);
            corrida.setTempoDeQualificacao(0);
            qualify.setQtdVoltas(0);
            qualify.setTempoDeQualificacao(0);
            existeCorrida = false;
        }
        return existeCorrida;
        
    }
    
    public boolean cadastrarJogadores(String nome, String equipe){
        boolean existeNome = false;
        for(Jogador jog: jogadores){
            if(jog.getNome().equals(nome)){
                existeNome = true;
                break;
            }
        }
        if(!existeNome){
            Jogador jogador = new Jogador(nome,equipe);
            jogadores.add(jogador);
            return true;
            
        }else{
            return false;
        }
    }
    
    public boolean cadastrarCarro(int numero, Color cor, String tag){
        boolean cadastrou = true;
        for(Carro c : carros){
            if(numero==c.getNumero()){
                cadastrou = false;
            }
        }
        if(cadastrou){
            Carro carro = new Carro(numero, cor, tag);
            carros.add(carro);
        }
        return cadastrou;
    }
    
    
    public static Handler getInstance(){
        if(han==null){
            han = new Handler();
            existeCorrida = false;
        }
        return han;
    }

    public void cadastroADM(String nome, String senha) {
        Administrador adm = new Administrador(nome,senha);
        adms.add(adm);
    }
        

    public void escreverArquivoSerial(String nome, Object obj) throws FileNotFoundException, IOException{
        //Classe responsavel por inserir os objetos
        try (FileOutputStream arquivo = new FileOutputStream(nome)) {
            //Grava o objeto cliente no arquivo
            try ( //Classe responsavel por inserir os objetos
                    ObjectOutputStream objGravar = new ObjectOutputStream(arquivo)) {
                //Grava o objeto cliente no arquivo
                objGravar.writeObject(obj);
                objGravar.flush();
            }
            arquivo.flush();
        }
    }
    
    public void lerArquivoSerial(String nome) throws FileNotFoundException, IOException, ClassNotFoundException{
        Object obj;
        try{
            // Classe responsavel por recuperar os objetos do arquivo
            try (FileInputStream arquivo = new FileInputStream(nome); // Classe responsavel por recuperar os objetos do arquivo
                    ObjectInputStream leitura = new ObjectInputStream(arquivo)) {
                obj = leitura.readObject();
            }
            switch (nome) {
                case "dados\\ADM\\listaADM":
                    adms = (List<Administrador>) obj;
                    break;
                case "dados\\Carros\\listaCARRO":
                    carros = (List<Carro>) obj;
                    break;
                case "dados\\Jogadores\\listaJOGADOR":
                    jogadores = (List<Jogador>) obj;
                    break;
                case "dados\\Recordes\\recordeQualify":
                    recordeQualify = (Recorde) obj;
                    break;
                case "dados\\Recordes\\recordeCorrida":
                    recordeCorrida = (Recorde) obj;
                    break;
                default:
                    break;
            }
        }
        catch(FileNotFoundException fnfe){
            System.out.println("Ainda não existe nenhum arquivo com esse caminho => " + nome);     
        }
        
        
    }
}

