package servidor;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;

/**
 *
 * @author allan
 */
public class Servidor {

    /**
     * @throws java.io.IOException
     */
    private static final int PORTA = 12345;
    static Handler han = Handler.getInstance();
    private static JTable tabelaCorri;
    private static JTable tabelaQuali;

    public static void main(String[] args) throws IOException {
        ouvirTCP();
        ouvirUDP();
    }

    public static void ouvirTCP() throws IOException {
        ServerSocket servidor = new ServerSocket(PORTA);
        System.out.println("Conectado com sucesso");
        //Server thread = new Server(servidor);
        //Thread t = new Thread(thread);
        //t.start
        new Thread() {
            @Override
            public void run() {
                while (true) {
                    System.out.println("Esperando cliente......");
                    Socket cliente;
                    try {
                        cliente = servidor.accept();
                        System.out.println("cliente conectado");
                        ObjectInputStream in = new ObjectInputStream(cliente.getInputStream());
                        ObjectOutputStream out = new ObjectOutputStream(cliente.getOutputStream());
                        ThreadTCP thread = new ThreadTCP(cliente, in, out, han);
                        Thread t = new Thread(thread);
                        t.start();
                    } catch (IOException ex) {

                    }

                }
            }
        
        }.start();
    }

    public static void ouvirUDP() throws IOException {

        DatagramSocket serverSocket = new DatagramSocket(PORTA);
        byte[] receiveData = new byte[1024];
        new Thread() {
            @Override
            public void run() {
                while (true) {
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    try {
                        serverSocket.receive(receivePacket);
                    } catch (IOException ex) {
                        Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    //System.out.println("Datagrama UDP [" + numConn + "] recebido...");
                    ThreadUDP thr = new ThreadUDP(receivePacket, tabelaCorri, tabelaQuali, han);
                    Thread t = new Thread(thr);
                    t.start();
                }
            }
        }.start();

    }

    public static void receberTable(JTable a, JTable b) {
        tabelaCorri = a;
        tabelaQuali = b;
    }
}
