/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import cliente.Jogador;
import cliente.Recorde;
import cliente.Sensor;
//import static cliente.Simulador.acontecendoqualify;
//import static cliente.Simulador.corrida;
import java.io.IOException;
import java.net.DatagramPacket;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;

/**
 *
 * @author User
 */
public class ThreadUDP implements Runnable {

    private static JTable tabelaCorri;
    private static JTable tabelaQuali;
    static boolean finalizar;
    private final DatagramPacket receive;
    public static List<Sensor> lista = new CopyOnWriteArrayList<Sensor>();
    private static Handler han;
    public static boolean verifica;
    public static List<Sensor> tratamento = new CopyOnWriteArrayList<>();
    private static boolean execQualify = false;
    private static boolean execCorrida = false;

    ThreadUDP(DatagramPacket receivePacket, JTable tabelaCorri, JTable tabelaQuali, Handler han) {
        this.receive = receivePacket;
        ThreadUDP.tabelaCorri = tabelaCorri;
        ThreadUDP.tabelaQuali = tabelaQuali;
        ThreadUDP.han = han;
    }

    @Override
    public void run() {

        String str = new String(receive.getData());
        System.out.println("Mensagem: " + str);
        String[] str2;
        str2 = str.split(",");
        String[] str3;
        str3 = str2[1].split("T");

        float tempo = Float.parseFloat(str3[1].split(":")[2]);
        System.out.println("Tempo dps do parse = " + tempo);
        Sensor sens = new Sensor(str2[0], str3[1]);

        lista.add(sens);
        //System.out.println(lista);
        try {
            eliminarRajada(sens);
            if (Handler.corrida.getJogadores().get(Handler.corrida.getJogadores().size() - 1).getVoltas() == Handler.corrida.getQtdVoltas()) {
                finalizar = true;
                execQualify = false;
                execCorrida = false;

            }
            atualizar();
        } catch (IOException | ClassNotFoundException | InterruptedException ex) {
            Logger.getLogger(ThreadUDP.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * método responsável por atualizar tabela da interface
     *
     * @throws IOException
     * @throws ClassNotFoundException
     * @throws InterruptedException
     */
    public void atualizar() throws IOException, ClassNotFoundException, InterruptedException {//4voltas
        int colunas;
        if (execQualify == false) {
            colunas = tabelaCorri.getColumnCount();
            for (int linha = 0; linha < Handler.corrida.getJogadores().size(); linha++) {
                for (int col = 0; col < colunas; col++) {
                    // posição, piloto, equipe, tempo de corrida, tempo de volta, volta mais rapida, voltas
                    if (Handler.corrida.getJogadores().get(linha).getVoltas() > Handler.corrida.getQtdVoltas()) {
                        break;
                    }
                    switch (col) {
                        case 0:
                            tabelaCorri.getModel().setValueAt(Handler.corrida.getJogadores().get(linha).getPosicao(), linha, col);
                            break;
                        case 1:
                            tabelaCorri.getModel().setValueAt(Handler.corrida.getJogadores().get(linha).getNome(), linha, col);
                            break;
                        case 2:
                            tabelaCorri.getModel().setValueAt(Handler.corrida.getJogadores().get(linha).getEquipe(), linha, col);
                            break;
                        case 3:
                            tabelaCorri.getModel().setValueAt(Handler.corrida.getJogadores().get(linha).getTempoCorrida(), linha, col);
                            break;
                        case 4:
                            tabelaCorri.getModel().setValueAt(Handler.corrida.getJogadores().get(linha).getTempoVolta(), linha, col);
                            break;
                        case 5:
                            tabelaCorri.getModel().setValueAt(Handler.corrida.getJogadores().get(linha).getVoltaRapida(), linha, col);
                            break;
                        case 6:
                            tabelaCorri.getModel().setValueAt(Handler.corrida.getJogadores().get(linha).getVoltas(), linha, col);
                            break;
                        default:
                            break;
                    }

                }
            }
        } else {
            colunas = tabelaQuali.getColumnCount();
            for (int linha = 0; linha < Handler.qualify.getJogadores().size(); linha++) {
                for (int col = 0; col < colunas; col++) {
                    // posição, piloto, equipe, tempo de corrida, tempo de volta, volta mais rapida, volta
                    switch (col) {
                        case 0:
                            tabelaQuali.getModel().setValueAt(linha + 1, linha, col);
                            break;
                        case 1:
                            tabelaQuali.getModel().setValueAt(Handler.qualify.getJogadores().get(linha).getNome(), linha, col);
                            break;
                        case 2:
                            tabelaQuali.getModel().setValueAt(Handler.qualify.getJogadores().get(linha).getEquipe(), linha, col);
                            break;
                        case 3:
                            tabelaQuali.getModel().setValueAt(Handler.qualify.getJogadores().get(linha).getTempoVolta(), linha, col);
                            break;
                        case 4:
                            tabelaQuali.getModel().setValueAt(Handler.qualify.getJogadores().get(linha).getVoltaRapida(), linha, col);
                            break;
                        case 5:
                            tabelaQuali.getModel().setValueAt(Handler.qualify.getJogadores().get(linha).getVoltas(), linha, col);
                            break;
                        default:
                            break;
                    }

                }
            }
        }
    }

    public static void insertionSort(Jogador[] vetor) {
        int j;
        Jogador key;
        int i;
        for (j = 1; j < vetor.length; j++) {
            key = vetor[j];
            for (i = j - 1; (i >= 0) && (vetor[i].getVoltaRapida() > key.getVoltaRapida()); i--) {
                vetor[i + 1] = vetor[i];
            }
            vetor[i + 1] = key;
        }
    }

    /**
     * método responsável por eliminar a rajada de tag repetida do sensor e
     * representar o envio de tags como uma corrida
     *
     * @param sensor
     */
    private void eliminarRajada(Sensor sensor) throws IOException {

        Sensor tempo = null;
        
        verifica = true;
        if(tratamento.isEmpty() ){
            tratamento.add(sensor);
            tempo = sensor;
        }else{
            tempo = tratamento.get(tratamento.size()-1);
            if(calcularDiferencaDeTempo(tempo, sensor) < 3 && tempo.getTag().equals(sensor.getTag())){
                verifica = false;
            }
        }
        
            

        if (verifica) {
            if (execQualify == false && execCorrida == false) { // é a primeira vez que viemos aqui, portanto deve-se executar o qualify
                System.out.println("entrou no if 1");
                System.out.println(tempo);
                executarQualify(sensor.getTag(), tempo, sensor);
            } else if (execQualify == true && execCorrida == false) { // é a segunda ou enésima vez que viemos aqui, ainda deve-se executar o qualify
                executarQualify(sensor.getTag(), tempo, sensor);
            } else if (execQualify == false && execCorrida == true) { // devemos executar a corrida
                executarCorrida(sensor.getTag(), tempo, sensor);
            } else {

            }
            
            tratamento.add(sensor);
        }

    }

    public void executarCorrida(String tag, Sensor tempo1, Sensor tempo2) {

        for (int i = 0; i < Handler.corrida.getJogadores().size(); i++) {
            System.out.println(Handler.corrida.getJogadores().get(i).getCarro().getTag());
            System.out.println(tag);
            if (Handler.corrida.getJogadores().get(i).getCarro().getTag().equals(tag)) {

                Handler.corrida.getJogadores().get(i).setVoltas(Handler.corrida.getJogadores().get(i).getVoltas() + 1);
                Handler.corrida.getJogadores().get(i).setTempoVolta(calcularDiferencaDeTempo(tempo1, tempo2));
                Handler.corrida.getJogadores().get(i).melhorVolta(calcularDiferencaDeTempo(tempo1, tempo2));
                Handler.corrida.getJogadores().get(i).setTempoCorrida(Handler.corrida.getJogadores().get(i).getTempoCorrida() + Handler.corrida.getJogadores().get(i).getTempoVolta());
            }
        }
        ordenarCorrida();
        for (int i = 0; i < Handler.corrida.getJogadores().size(); i++) {
            Handler.corrida.getJogadores().get(i).setPosicao(i + 1);
            System.out.println(Handler.corrida.getJogadores().get(i).toStringComCarro());
        }
    }

    public void executarQualify(String tag, Sensor tempo1, Sensor tempo2) {

        for (int i = 0; i < Handler.qualify.getJogadores().size(); i++) {
            System.out.println(Handler.corrida.getJogadores().get(i).getCarro().getTag());
            System.out.println(tag);
            if (Handler.qualify.getJogadores().get(i).getCarro().getTag().equals(tag)) {
                System.out.println("identificou a tag");
                Handler.qualify.getJogadores().get(i).setVoltas(Handler.qualify.getJogadores().get(i).getVoltas() + 1);
                Handler.qualify.getJogadores().get(i).setTempoVolta(calcularDiferencaDeTempo(tempo1, tempo2));
                Handler.qualify.getJogadores().get(i).melhorVolta(calcularDiferencaDeTempo(tempo1, tempo2));
                Handler.qualify.getJogadores().get(i).setTempoCorrida(Handler.qualify.getJogadores().get(i).getTempoCorrida() + Handler.qualify.getJogadores().get(i).getTempoVolta());
            }
        }
        ordenarQualify();

        if (Handler.qualify.getJogadores().get(Handler.qualify.getJogadores().size() - 1).getTempoCorrida() >= Handler.qualify.getTempoDeQualificacao()) {
            execCorrida = true;
            execQualify = false;
        } else {
            execCorrida = false;
            execQualify = true;
        }

        for (int i = 0; i < Handler.qualify.getJogadores().size(); i++) {

            System.out.println(Handler.qualify.getJogadores().get(i).toStringComCarro());
        }

    }

    /**
     * método responsável por ordenar os jogadores da corrida de acordo com sua
     * quantidade de voltas e seu tempo
     */
    private static void ordenarCorrida() {
        /*List<Jogador> ordenada = new LinkedList();
        int vol = -1;
        List aux = new LinkedList();
        for (int i = 0; i < Handler.corrida.getJogadores().size(); i++) {
            if (Handler.corrida.getJogadores().get(i).getVoltas() > vol) {
                vol = Handler.corrida.getJogadores().get(i).getVoltas();
            }
        }
        for (int i = vol; i > -1; i--) {
            List<Jogador> aux2 = new LinkedList();
            for (int j = 0; j < Handler.corrida.getJogadores().size(); j++) {
                if (Handler.corrida.getJogadores().get(j).getVoltas() == i) {
                    aux2.add(Handler.corrida.getJogadores().get(j));
                }
            }
            aux.add(aux2);
        }
        for (int i = 0; i < aux.size(); i++) {
            List<Jogador> aux2 = (List<Jogador>) aux.get(i);
            Collections.sort(aux2);
            ordenada.addAll(aux2);
        }
        Collections.copy(Handler.corrida.getJogadores(), ordenada);
         */
        Collections.sort(Handler.corrida.getJogadores());
    }

    public static void checarRecordeCorrida() throws IOException {
        Recorde rec;
        if (Handler.recordeCorrida != null) { // verifico se o recorde salvo no arquivo existe
            // se existe então se o recorde dessa corrida
            rec = Handler.recordeCorrida;
            for (int i = 0; i < Handler.corrida.getJogadores().size(); i++) {
                if (Handler.corrida.getJogadores().get(i).getVoltaRapida() < rec.getRecorde()) {
                    rec.setNome(Handler.corrida.getJogadores().get(i).getNome());
                    rec.setEquipe(Handler.corrida.getJogadores().get(i).getEquipe());
                    rec.setRecorde(Handler.corrida.getJogadores().get(i).getVoltaRapida());
                }
            }
            han.escreverArquivoSerial("dados\\Recordes\\recordeCorrida", rec);
        } else { // se o recorde não existe... então essa é a primeira corrida, logo, esse é o primeiro recorde
            rec = new Recorde(Handler.corrida.getJogadores().get(0).getNome(),
                    Handler.corrida.getJogadores().get(0).getVoltaRapida(),
                    Handler.corrida.getJogadores().get(0).getEquipe());
            for (int i = 0; i < Handler.corrida.getJogadores().size(); i++) {
                if (Handler.corrida.getJogadores().get(i).getVoltaRapida() < rec.getRecorde()) {
                    rec = new Recorde(Handler.corrida.getJogadores().get(i).getNome(),
                            Handler.corrida.getJogadores().get(i).getVoltaRapida(),
                            Handler.corrida.getJogadores().get(i).getEquipe());
                }
            }
            Handler.recordeCorrida = rec;
            han.escreverArquivoSerial("dados\\Recordes\\recordeCorrida", rec);
        }
    }

    public static void checarRecordeQualify() throws IOException {
        Recorde rec;
        System.out.println(Handler.recordeQualify.toString());
        if (Handler.recordeQualify == null) {
            rec = new Recorde(Handler.qualify.getJogadores().get(0).getNome(),
                    Handler.qualify.getJogadores().get(0).getVoltaRapida(),
                    Handler.qualify.getJogadores().get(0).getEquipe());
            han.escreverArquivoSerial("dados\\Recordes\\recordeQualify", rec);
            Handler.recordeQualify = rec;
            System.out.println("if : " + Handler.recordeQualify.toString());
        } else {
            if (Handler.recordeQualify.getRecorde() > Handler.qualify.getJogadores().get(0).getVoltaRapida()) {
                rec = new Recorde(Handler.qualify.getJogadores().get(0).getNome(),
                        Handler.qualify.getJogadores().get(0).getVoltaRapida(),
                        Handler.qualify.getJogadores().get(0).getEquipe());
                han.escreverArquivoSerial("dados\\Recordes\\recordeQualify", rec);
                Handler.recordeQualify = rec;
                System.out.println("else : " + Handler.recordeQualify.toString());

            }
            System.out.println("não entrou");
        }
    }

    private static Jogador[] transformarEmVetor() {
        Jogador[] jog = new Jogador[Handler.qualify.getJogadores().size()];
        for (int i = 0; i < jog.length; i++) {
            jog[i] = Handler.qualify.getJogadores().get(i);
        }
        return jog;
    }

    private static void ordenarQualify() {
        Jogador[] vet = transformarEmVetor();
        insertionSort(vet);
        //System.out.println("Exibindo vetor");
        List<Jogador> ordem = new LinkedList<>();
        for (int i = 0; i < vet.length; i++) {
            ordem.add(vet[i]);
        }
        Handler.qualify.setJogadores(ordem);

    }

    private float calcularDiferencaDeTempo(Sensor tempo1, Sensor tempo2) {

        LocalTime entrada = LocalTime.of(tempo1.getHoras(), tempo1.getMinutos(),  tempo1.getSegundos());
        LocalTime saida = LocalTime.of(tempo2.getHoras(), tempo2.getMinutos(),  tempo2.getSegundos());

        float intervalo = ChronoUnit.MILLIS.between(entrada, saida);
        float inter = (intervalo / 1000);
        System.out.println("A diferença é de " + inter + " segundos.");

        return inter;
    }

}
