package servidor;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cliente.Administrador;
import cliente.Carro;
import cliente.Corrida;
import cliente.Jogador;
import cliente.Protocolo;
import cliente.Recorde;
import cliente.Sensor;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author allan
 */
public class ThreadServidor implements Runnable {

    private final Socket cliente;
    private final ObjectInputStream in;
    private final ObjectOutputStream out;
    List<Sensor> tratamento = new ArrayList<>();
    private static Handler han;
    public static boolean verifica; // verifica se pode ou não atualizar o dado da corrida na tela na tela
    private static boolean finalize;
    private static boolean execQualify;
    private static boolean execCorrida;

    ThreadServidor(Socket cliente, ObjectInputStream in, ObjectOutputStream out, Handler han) {
        this.cliente = cliente;
        this.in = in;
        this.out = out;
        ThreadServidor.han = han;
    }

    @Override
    public void run() {
        // crio uma variável do tipo random para posteriormente simular uma corrida

        try {
            // carrego os dados que estão nos arquivos do sistema
            carregarDados();

        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(ThreadServidor.class.getName()).log(Level.SEVERE, null, ex);
        }
        int protocoloAtual;
        while (true) {
            try {
                protocoloAtual = (int) input(); // recebe o protocolo que vem do cliente

                if (protocoloAtual == Protocolo.SAIR) { // desconecta o cliente
                    sair();
                    break;
                } else if (protocoloAtual == Protocolo.CADASTRO_ADM) { // faz o cadastro de um administrador
                    Administrador admin = (Administrador) input();
                    han.cadastroADM(admin.getNome(), admin.getSenha());
                    han.escreverArquivoSerial("dados\\ADM\\listaADM", Handler.adms);
                } else if (protocoloAtual == Protocolo.CADASTRO_CARRO) { // faz o cadastro de um carro
                    Carro carro = (Carro) input();
                    boolean cadastrou = han.cadastrarCarro(carro.getNumero(), carro.getCor(), carro.getTag());
                    output(cadastrou);
                    han.escreverArquivoSerial("dados\\Carros\\listaCARRO", Handler.carros);
                } else if (protocoloAtual == Protocolo.CADASTRO_USUARIO) { // faz o cadastro de um usuário normal
                    Jogador jog = (Jogador) input();
                    System.out.println(jog.toString());
                    boolean cadastrou = han.cadastrarJogadores(jog.getNome(), jog.getEquipe());
                    output(cadastrou);
                    han.escreverArquivoSerial("dados\\Jogadores\\listaJOGADOR", Handler.jogadores);
                } else if (protocoloAtual == Protocolo.CORRIDA) { // faz o cadastro de uma corrida

                    output(Handler.existeCorrida);
                    output(Handler.jogadores);
                    output(Handler.carros);
                    try {
                        boolean cadastrar = (boolean) input();
                        if (cadastrar) { // se cadastrar for true o sistema pode chamar o handler pra efetuar o cadastro
                            Corrida corrida = (Corrida) input();
                            Corrida qualify = (Corrida) input();
                            han.cadastrarCorrida(corrida);
                            han.cadastrarQualify(qualify);
                        }
                    } catch (java.lang.ClassCastException ex) {
                        sair();
                        break;
                    }

                } else if (protocoloAtual == Protocolo.LISTAR_CORRIDA_CADASTRADA) { // se existir uma corrida cadastrada o servidor envia essa corrida ao cliente
                    boolean existeCorrida = Handler.existeCorrida;
                    output(existeCorrida);
                    if (existeCorrida) {
                        output(Handler.corrida);
                    }
                } else if (protocoloAtual == Protocolo.PEGAR_RECORDE) {
                    output(Handler.recordeCorrida);
                    output(Handler.recordeQualify);
                } else if (protocoloAtual == Protocolo.LOGIN) {
                    Administrador adm = (Administrador) input();
                    boolean podeLogar = false;
                    for (Administrador ad : Handler.adms) {
                        if (ad.getNome().equals(adm.getNome()) && ad.getSenha().equals(adm.getSenha())) {
                            podeLogar = true;
                        }
                    }
                    if (adm.getNome().equals("admin") && adm.getSenha().equals("admin")) {
                        podeLogar = true;
                    }
                    output(podeLogar);
                } else if (protocoloAtual == Protocolo.INICIAR_SIMULA) {

                    Sensor tags = (Sensor) input();
                    System.out.println(tags.toString());
                    eliminarRajada(tags);
                    finalize = false;
                    if (Handler.corrida.getJogadores().get(Handler.corrida.getJogadores().size() - 1).getVoltas() == Handler.corrida.getQtdVoltas()) {
                        finalize = true;
                        execQualify = false;
                        execCorrida = false;
                    }
                    output(finalize);
                    output(verifica);
                    output(execQualify);
                    if (execQualify) {
                        output(Handler.qualify);
                    } else {
                        output(Handler.corrida);
                    }

                } else if (protocoloAtual == Protocolo.FINALIZAR_CORRIDA) {
                    checarRecordeQualify();
                    checarRecordeCorrida();
                    han.finalizarQualificacaoECorrida();
                    System.out.println("finalizou serv");
                } else if (protocoloAtual == Protocolo.ATUALIZAR_CORRIDA) {
                    output(Handler.corrida);

                }
            } catch (IOException | ClassNotFoundException ex) {
                System.out.println("jdjasdjiasdoasdio");
                Logger.getLogger(ThreadServidor.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    public Object input() throws IOException, ClassNotFoundException {
        return in.readObject();
    }

    public void output(Object msg) throws IOException {
        out.flush();
        out.writeObject(msg);
        out.reset();
    }

    //chama o handler pra carregar os arquivos salvos no sistema
    public static void carregarDados() throws IOException, FileNotFoundException, ClassNotFoundException {
        han.lerArquivoSerial("dados\\ADM\\listaADM");
        han.lerArquivoSerial("dados\\Carros\\listaCARRO");
        han.lerArquivoSerial("dados\\Jogadores\\listaJOGADOR");
        han.lerArquivoSerial("dados\\Recordes\\recordeQualify");
        han.lerArquivoSerial("dados\\Recordes\\recordeCorrida");
    }

    /**
     * método de ordenação onde a chave é a posição que os jogadores recebem de
     * maneira aleatória por enquanto
     *
     * @param vetor
     */
    public static void insertionSort(Jogador[] vetor) {
        int j;
        Jogador key;
        int i;
        for (j = 1; j < vetor.length; j++) {
            key = vetor[j];
            for (i = j - 1; (i >= 0) && (vetor[i].getVoltaRapida() > key.getVoltaRapida()); i--) {
                vetor[i + 1] = vetor[i];
            }
            vetor[i + 1] = key;
        }
    }

    /**
     * método responsável por eliminar a rajada de tag repetida do sensor e
     * representar o envio de tags como uma corrida
     *
     * @param sensor
     */
    private void eliminarRajada(Sensor sensor) throws IOException {
        String tag = sensor.getTag();
        float tempoAtual = sensor.getTempo();
        if (!(tempoAtual < 5)) {
            float tempo = 0;
            Iterator it = tratamento.iterator();
            verifica = true;
            while (it.hasNext()) {
                Sensor s = (Sensor) it.next();
                if (s.getTag().equals(tag)) {
                    tempo = s.getTempo();
                    if (tempo * 1.2 < tempoAtual) { // pode alterar
                        it.remove();
                    } else {
                        verifica = false;
                    }
                    break;
                }
            }
            if (verifica) {
                if (execQualify == false && execCorrida == false) { // é a primeira vez que viemos aqui, portanto deve-se executar o qualify
                    executarQualify(tag, tempoAtual, tempo);
                } else if (execQualify == true && execCorrida == false) { // é a segunda ou enésima vez que viemos aqui, ainda deve-se executar o qualify
                    executarQualify(tag, tempoAtual, tempo);
                } else if (execQualify == false && execCorrida == true) { // devemos executar a corrida
                    executarCorrida(tag, tempoAtual, tempo);
                } else {

                }

                tratamento.add(sensor);
            }

        }
    }

    private void executarCorrida(String tag, float tempoAtual, float tempo) {
        for (int i = 0; i < Handler.corrida.getJogadores().size(); i++) {
            if (Handler.corrida.getJogadores().get(i).getCarro().getTag().equals(tag)) {
                Handler.corrida.getJogadores().get(i).setVoltas(Handler.corrida.getJogadores().get(i).getVoltas() + 1);
                Handler.corrida.getJogadores().get(i).setTempoVolta(tempoAtual - tempo);
                Handler.corrida.getJogadores().get(i).melhorVolta(tempoAtual - tempo);
                Handler.corrida.getJogadores().get(i).setTempoCorrida(Handler.corrida.getJogadores().get(i).getTempoCorrida() + Handler.corrida.getJogadores().get(i).getTempoVolta());
            }
        }
        ordenarCorrida();
        for (int i = 0; i < Handler.corrida.getJogadores().size(); i++) {
            Handler.corrida.getJogadores().get(i).setPosicao(i + 1);
        }
    }

    private void executarQualify(String tag, float tempoAtual, float tempo) {
        for (int i = 0; i < Handler.qualify.getJogadores().size(); i++) {
            if (Handler.qualify.getJogadores().get(i).getCarro().getTag().equals(tag)) {
                Handler.qualify.getJogadores().get(i).setVoltas(Handler.qualify.getJogadores().get(i).getVoltas() + 1);
                Handler.qualify.getJogadores().get(i).setTempoVolta(tempoAtual - tempo);
                Handler.qualify.getJogadores().get(i).melhorVolta(tempoAtual - tempo);
                Handler.qualify.getJogadores().get(i).setTempoCorrida(Handler.qualify.getJogadores().get(i).getTempoCorrida() + Handler.qualify.getJogadores().get(i).getTempoVolta());
            }
        }
        ordenarQualify();

        if (Handler.qualify.getJogadores().get(Handler.qualify.getJogadores().size() - 1).getTempoCorrida() >= Handler.qualify.getTempoDeQualificacao()) {
            execCorrida = true;
            execQualify = false;
        } else {
            execCorrida = false;
            execQualify = true;
        }
    }

    /**
     * método responsável por ordenar os jogadores da corrida de acordo com sua
     * quantidade de voltas e seu tempo
     */
    private void ordenarCorrida() {
        /*List<Jogador> ordenada = new LinkedList();
        int vol = -1;
        List aux = new LinkedList();
        for (int i = 0; i < Handler.corrida.getJogadores().size(); i++) {
            if (Handler.corrida.getJogadores().get(i).getVoltas() > vol) {
                vol = Handler.corrida.getJogadores().get(i).getVoltas();
            }
        }
        for (int i = vol; i > -1; i--) {
            List<Jogador> aux2 = new LinkedList();
            for (int j = 0; j < Handler.corrida.getJogadores().size(); j++) {
                if (Handler.corrida.getJogadores().get(j).getVoltas() == i) {
                    aux2.add(Handler.corrida.getJogadores().get(j));
                }
            }
            aux.add(aux2);
        }
        for (int i = 0; i < aux.size(); i++) {
            List<Jogador> aux2 = (List<Jogador>) aux.get(i);
            Collections.sort(aux2);
            ordenada.addAll(aux2);
        }
        Collections.copy(Handler.corrida.getJogadores(), ordenada);
        */
        Collections.sort(Handler.corrida.getJogadores());
    }

    private void sair() throws IOException {
        in.close();
        out.close();
        cliente.close();
        System.out.println("CLIENTE DESCONECTOU");
    }

    private void checarRecordeCorrida() throws IOException {
        Recorde rec;
        if (Handler.recordeCorrida != null) { // verifico se o recorde salvo no arquivo existe
            // se existe então se o recorde dessa corrida
            rec = Handler.recordeCorrida;
            for (int i = 0; i < Handler.corrida.getJogadores().size(); i++) {
                if (Handler.corrida.getJogadores().get(i).getVoltaRapida() < rec.getRecorde()) {
                    rec.setNome(Handler.corrida.getJogadores().get(i).getNome());
                    rec.setEquipe(Handler.corrida.getJogadores().get(i).getEquipe());
                    rec.setRecorde(Handler.corrida.getJogadores().get(i).getVoltaRapida());
                }
            }
            han.escreverArquivoSerial("dados\\Recordes\\recordeCorrida", rec);
        } else { // se o recorde não existe... então essa é a primeira corrida, logo, esse é o primeiro recorde
            rec = new Recorde(Handler.corrida.getJogadores().get(0).getNome(),
                    Handler.corrida.getJogadores().get(0).getVoltaRapida(),
                    Handler.corrida.getJogadores().get(0).getEquipe());
            for (int i = 0; i < Handler.corrida.getJogadores().size(); i++) {
                if (Handler.corrida.getJogadores().get(i).getVoltaRapida() < rec.getRecorde()) {
                    rec = new Recorde(Handler.corrida.getJogadores().get(i).getNome(),
                            Handler.corrida.getJogadores().get(i).getVoltaRapida(),
                            Handler.corrida.getJogadores().get(i).getEquipe());
                }
            }
            Handler.recordeCorrida = rec;
            han.escreverArquivoSerial("dados\\Recordes\\recordeCorrida", rec);
        }
    }

    private void checarRecordeQualify() throws IOException {
        Recorde rec;
        System.out.println(Handler.recordeQualify.toString());
        if (Handler.recordeQualify == null) {
            rec = new Recorde(Handler.qualify.getJogadores().get(0).getNome(),
                    Handler.qualify.getJogadores().get(0).getVoltaRapida(),
                    Handler.qualify.getJogadores().get(0).getEquipe());
            han.escreverArquivoSerial("dados\\Recordes\\recordeQualify", rec);
            Handler.recordeQualify = rec;
            System.out.println("if : " + Handler.recordeQualify.toString());
        } else {
            if (Handler.recordeQualify.getRecorde() > Handler.qualify.getJogadores().get(0).getVoltaRapida()) {
                rec = new Recorde(Handler.qualify.getJogadores().get(0).getNome(),
                        Handler.qualify.getJogadores().get(0).getVoltaRapida(),
                        Handler.qualify.getJogadores().get(0).getEquipe());
                han.escreverArquivoSerial("dados\\Recordes\\recordeQualify", rec);
                Handler.recordeQualify = rec;
                System.out.println("else : " + Handler.recordeQualify.toString());

            }
            System.out.println("não entrou");
        }
    }

    private Jogador[] transformarEmVetor() {
        Jogador[] jog = new Jogador[Handler.qualify.getJogadores().size()];
        for (int i = 0; i < jog.length; i++) {
            jog[i] = Handler.qualify.getJogadores().get(i);
        }
        return jog;
    }

    private void ordenarQualify() {
        Jogador[] vet = transformarEmVetor();
        insertionSort(vet);
        //System.out.println("Exibindo vetor");
        List<Jogador> ordem = new LinkedList<>();
        for (int i = 0; i < vet.length; i++) {
            ordem.add(vet[i]);
        }
        Handler.qualify.setJogadores(ordem);

    }

}
