/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

/**
 *
 * @author allan
 */
public class Protocolo {
    public static int LOGIN = 0;
    public static int SAIR = 1;
    public static int CADASTRO_USUARIO = 2;
    public static int CADASTRO_ADM = 3;
    public static int CORRIDA = 4;
    public static int CADASTRO_CARRO = 5;
    public static int LISTAR_CORRIDA_CADASTRADA = 6;
    public static int PEGAR_RECORDE = 7;
    public static int INICIAR_QUALIFY = 8;
    public static int FINALIZAR_CORRIDA = 9;
    public static int INICIAR_SIMULA = 10;
    public static int ATUALIZAR_CORRIDA = 11;
}
