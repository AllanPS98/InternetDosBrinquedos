/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import cliente.Sensor;
import static cliente.Simulador.acontecendoqualify;
import static cliente.Simulador.corrida;
import java.io.IOException;
import java.net.DatagramPacket;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import view.ConfigurarCorrida;

/**
 *
 * @author User
 */
public class ThreadUDP implements Runnable {

    private static JTable tabelaCorri;
    private static JTable tabelaQuali;
    private final DatagramPacket receive;
    public static List<Sensor> lista = new CopyOnWriteArrayList<Sensor>();

    ThreadUDP(DatagramPacket receivePacket, JTable tabelaCorri, JTable tabelaQuali) {
        this.receive = receivePacket;
        ThreadUDP.tabelaCorri = tabelaCorri;
        ThreadUDP.tabelaQuali = tabelaQuali;

    }

    @Override
    public void run() {
        String str = new String(receive.getData());
        System.out.println("Mensagem: " + str);
        String[] str2;

        str2 = str.split(",");
        //System.out.println("Tag: "+str2[0]);
        //System.out.println("Tempo: "+str2[1]);
        String[] str3;
        //Sensor sens = new Sensor();
        str3 = str2[1].split("T");
        //System.out.println("Segundos = " + str3[2]);
        String tim = str3[1];
        float tempo = 0;

        SimpleDateFormat time = new SimpleDateFormat("HH:mm:ss.SSS");
        try {
            Date date = time.parse(tim);
            float mil = date.getTime();
            tempo = mil / 1000;
        } catch (ParseException ex) {
            Logger.getLogger(ThreadUDP.class.getName()).log(Level.SEVERE, null, ex);
        }

        Sensor sens = new Sensor(str2[0], tempo);
        //System.out.println("Sensor = " + sens.toString());
        lista.add(sens);
        System.out.println(lista);
        try {
            atualizar();
        } catch (IOException | ClassNotFoundException | InterruptedException ex) {
            Logger.getLogger(ThreadUDP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void atualizar() throws IOException, ClassNotFoundException, InterruptedException {//4voltas
        int colunas;

        colunas = tabelaQuali.getColumnCount();
        for (int linha = 0; linha < ConfigurarCorrida.qtdLinha; linha++) {
            for (int col = 0; col < colunas; col++) {
                // posição, piloto, equipe, tempo de corrida, tempo de volta, volta mais rapida, volta
                switch (col) {
                    case 0:
                        tabelaQuali.getModel().setValueAt(linha + 1, linha, col);
                        break;
                    case 1:
                        tabelaQuali.getModel().setValueAt(lista.get(linha).getTag(), linha, col);
                        break;
                    case 2:
                        tabelaQuali.getModel().setValueAt(lista.get(linha).getTempo(), linha, col);
                        break;
                }

            }
        }
    }

}
