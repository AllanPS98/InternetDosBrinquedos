/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;

/**
 *
 * @author User
 */
public class ServidorUDP implements Runnable {

    /**
     * @param args the command line arguments
     * @throws java.net.SocketException
     */
    private static JTable tabelaCorri; 
    private static JTable tabelaQuali;
    private static DatagramSocket serverSocket;
    private static byte[] receiveData;
    public ServidorUDP(JTable tabelaCorri, JTable tabelaQuali) throws IOException{
        ServidorUDP.tabelaCorri = tabelaCorri;
        ServidorUDP.tabelaQuali = tabelaQuali;
        int porta = 12345;
        serverSocket = new DatagramSocket(porta);
        receiveData = new byte[1024];
        System.out.println("Esperando por datagrama UDP na porta " + porta);

    }
    
    public void receber() throws IOException{
        
        while (true) {
            DatagramPacket receivePacket = new DatagramPacket(receiveData,receiveData.length);
            serverSocket.receive(receivePacket);
            //System.out.println("Datagrama UDP [" + numConn + "] recebido...");
            ThreadUDP thr = new ThreadUDP(receivePacket, tabelaCorri, tabelaQuali);
            Thread t = new Thread(thr);
            t.start();
        }
    }

    @Override
    public void run() {
        try {
            receber();
        } catch (IOException ex) {
            Logger.getLogger(ServidorUDP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
