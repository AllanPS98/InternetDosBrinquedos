- Primeiro executa o servidor
- Segundo executa a tela inicial (login: admin | senha: admin)
- O restante a interface d� conta

Obs:
Para selecionar participante e carro, seleciona 1 jogador para 1 carro, que eu deixei previamente cadastrado 
e clica em incluir. Se fizer errado vai dar exece��o, ainda n�o tratei, por exemplo, escolher jogador e n�o escolher carro
e mesmo assim clicar em incluir.

Essa n�o � a vers�o final e eu tenho ci�ncia que faltam coisas pra implementar como a qualifica��o.
