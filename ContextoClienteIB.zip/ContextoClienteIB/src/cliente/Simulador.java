/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import java.util.LinkedList;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;


/**
 *
 * @author allan
 */
public class Simulador implements Runnable {

    ObjectOutputStream out;
    ObjectInputStream in;
    Socket cliente;
    public static Corrida corrida;
    public static boolean exec;
    public static boolean att;
    private final JTable tabelaCorri;
    private final JTable tabelaQuali;
    public static boolean finalizar;
    public static Recorde recordeCorrida;
    public static Recorde recordeQualify;
    public static boolean acontecendoqualify;

    
    /**
     * método responsável por simular o sensor RFID
     *
     * @param qtd
     * @throws InterruptedException
     * @throws IOException
     * @throws ClassNotFoundException
     */
    /*public void enviaTagCorrida(int qtd) throws InterruptedException, IOException, ClassNotFoundException {
        
        int i = 0;
        while (true) {
            System.out.println(ThreadUDP.lista);
            if (sensor.size()>0) {
                System.out.println("entrou no if");
                output(Protocolo.INICIAR_SIMULA);
                
                System.out.println(sensor.get(i).toString());
                output(sensor.get(i));
                System.out.println("mandou o dado");    
                finalizar = (boolean) input();
                att = (boolean) input();
                acontecendoqualify = (boolean) input();
                corrida = (Corrida) input();
                atualizar();

                if (finalizar && corrida.getJogadores().get(corrida.getJogadores().size() - 1).getVoltas() == qtd) {
                    return;
                }
                i++;
            }
        }
    }*/

    public Simulador(Socket cliente, ObjectOutputStream out, ObjectInputStream in, JTable tabelaCorri, JTable tabelaQuali) {
        this.cliente = cliente;
        this.out = out;
        this.in = in;
        this.tabelaCorri = tabelaCorri;
        this.tabelaQuali = tabelaQuali;
    }

    @Override
    public void run() {
        exec = true;
        //pegarRecorde();
        //inicializaSimulador();
        //enviaTagCorrida(Cliente.corrida.getQtdVoltas());
        //pegarRecorde();
        exec = false;

    }

    public void output(Object msg) throws IOException {
        out.flush();
        out.writeObject(msg);
        out.reset();
    }

    public Object input() throws IOException, ClassNotFoundException {
        return in.readObject();
    }

    public void sair() {
        try {
            output(Protocolo.SAIR);
            out.close();
            in.close();
            cliente.close();
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("CLIENTE DESCONECTADO !!!!!");
    }

    public Corrida retornaLista() {
        return corrida;
    }

    public void setLista(Corrida c) {
        corrida = c;
    }
    /*
    public void pegarRecorde() throws IOException, ClassNotFoundException {
        output(Protocolo.PEGAR_RECORDE);
        recordeCorrida = (Recorde) input();
        recordeQualify = (Recorde) input();

    }

    /**
     * método responsável por atualizar tabela da interface
     *
     * @throws IOException
     * @throws ClassNotFoundException
     * @throws InterruptedException
     */
    /*public void atualizar() throws IOException, ClassNotFoundException, InterruptedException {//4voltas
        int colunas;
        if (acontecendoqualify == false) {
            colunas = tabelaCorri.getColumnCount();
            for (int linha = 0; linha < ConfigurarCorrida.qtdLinha; linha++) {
                for (int col = 0; col < colunas; col++) {
                    // posição, piloto, equipe, tempo de corrida, tempo de volta, volta mais rapida, voltas
                    if (corrida.getJogadores().get(linha).getVoltas() > corrida.getQtdVoltas()) {
                        break;
                    }
                    switch (col) {
                        case 0:
                            tabelaCorri.getModel().setValueAt(corrida.getJogadores().get(linha).getPosicao(), linha, col);
                            break;
                        case 1:
                            tabelaCorri.getModel().setValueAt(corrida.getJogadores().get(linha).getNome(), linha, col);
                            break;
                        case 2:
                            tabelaCorri.getModel().setValueAt(corrida.getJogadores().get(linha).getEquipe(), linha, col);
                            break;
                        case 3:
                            tabelaCorri.getModel().setValueAt(corrida.getJogadores().get(linha).getTempoCorrida(), linha, col);
                            break;
                        case 4:
                            tabelaCorri.getModel().setValueAt(corrida.getJogadores().get(linha).getTempoVolta(), linha, col);
                            break;
                        case 5:
                            tabelaCorri.getModel().setValueAt(corrida.getJogadores().get(linha).getVoltaRapida(), linha, col);
                            break;
                        case 6:
                            tabelaCorri.getModel().setValueAt(corrida.getJogadores().get(linha).getVoltas(), linha, col);
                            break;
                        default:
                            break;
                    }

                }
            }
        } else {
            colunas = tabelaQuali.getColumnCount();
            for (int linha = 0; linha < ConfigurarCorrida.qtdLinha; linha++) {
                for (int col = 0; col < colunas; col++) {
                    // posição, piloto, equipe, tempo de corrida, tempo de volta, volta mais rapida, volta
                    switch (col) {
                        case 0:
                            tabelaQuali.getModel().setValueAt(linha + 1, linha, col);
                            break;
                        case 1:
                            tabelaQuali.getModel().setValueAt(corrida.getJogadores().get(linha).getNome(), linha, col);
                            break;
                        case 2:
                            tabelaQuali.getModel().setValueAt(corrida.getJogadores().get(linha).getEquipe(), linha, col);
                            break;
                        case 3:
                            tabelaQuali.getModel().setValueAt(corrida.getJogadores().get(linha).getTempoVolta(), linha, col);
                            break;
                        case 4:
                            tabelaQuali.getModel().setValueAt(corrida.getJogadores().get(linha).getVoltaRapida(), linha, col);
                            break;
                        case 5:
                            tabelaQuali.getModel().setValueAt(corrida.getJogadores().get(linha).getVoltas(), linha, col);
                            break;
                        default:
                            break;
                    }

                }
            }
        }
    }*/

}
